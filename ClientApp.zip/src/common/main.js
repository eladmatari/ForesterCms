// Transpiler for older browsers
import 'core-js/stable';
// optional but required for transforming generator fns.
import 'regenerator-runtime/runtime';
import * as Vue from 'vue'
import './main.scss';
import './fonts.scss';


//Vue.config.devtools = false;
