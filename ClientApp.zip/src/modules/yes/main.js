import './products.scss';

$(document).ready(function () {
    //alert(1);
});
console.log('yes')
